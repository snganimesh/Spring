package com.chain.api;

import javax.jms.ConnectionFactory;

import org.apache.activemq.RedeliveryPolicy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jms.connection.JmsTransactionManager;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.solacesystems.jms.SolXAConnectionFactory;
import com.solacesystems.jms.SolXAConnectionFactoryImpl;


//@EnableScheduling
@PropertySource({"classpath:persistence-multiple-db-boot.properties"})
@Configuration
public class SpringBootSender {

//	@Autowired	
//	private JmsTemplate jmsTemplate2;
	
	@Autowired
	public 	Environment env;

//	@PostConstruct
//	private void customizeJmsTemplate() {
//		// Update the jmsTemplate's connection factory to cache the connection
//		CachingConnectionFactory ccf = new CachingConnectionFactory();
//		ccf.setTargetConnectionFactory(jmsTemplate2.getConnectionFactory());
//		jmsTemplate2.setConnectionFactory(ccf);
////		// By default Spring Integration uses Queues, but if you set this to true you
////		// will send to a PubSub+ topic destination
//		jmsTemplate2.setPubSubDomain(false);
//	}
	
	 @Bean(name="solaceTransactionManager")
	    public PlatformTransactionManager solaceTransactionManager() {
	        JmsTransactionManager jmsTransactionManager = new JmsTransactionManager();
	        jmsTransactionManager.setConnectionFactory(jmsTemplate().getConnectionFactory());
	        return jmsTransactionManager;
	    }

	 
	
	 @Bean(name="solaceJmstemplate")
	    public JmsTemplate jmsTemplate() {
	        JmsTemplate jmsTemplate = new JmsTemplate();
	        jmsTemplate.setConnectionFactory(solConnectionFactory());
	        jmsTemplate.setDefaultDestinationName(env.getProperty("solaceTestQueue"));
	        return jmsTemplate;
	 }

	@Value("solaceTestQueue")
	private String queueName;

	//@Scheduled(fixedRate = 500)
	public void sendEvent() throws Exception {
		String msg = "Hello World " + System.currentTimeMillis();
		System.out.println("==========SENDING MESSAGE========== " + msg);
		jmsTemplate().convertAndSend(queueName, msg);
	}
	
	

	
	@Bean 
	public ConnectionFactory solConnectionFactory() { RedeliveryPolicy rp =
	new RedeliveryPolicy();
	rp.setMaximumRedeliveries(RedeliveryPolicy.NO_MAXIMUM_REDELIVERIES);

	// ActiveMQConnectionFactory connectionFactory = nActiveMQConnectionFactory();

	SolXAConnectionFactory connectionFactory = new SolXAConnectionFactoryImpl();
	connectionFactory.setHost(env.getProperty("solace.jms.host"));
	connectionFactory.setUsername(env.getProperty("solace.jms.clientUsername"));
	connectionFactory.setPassword(env.getProperty("solace.jms.clientPassword"));
	connectionFactory.setVPN(env.getProperty("solace.jms.msgVpn")); ///
	//connectionFactory.setRedeliveryPolicy(rp); 
	return connectionFactory; }
	 
    	
	

	
}
