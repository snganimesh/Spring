package com.chain.api;

import javax.jms.ConnectionFactory;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.RedeliveryPolicy;
import org.apache.camel.component.jms.JmsComponent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.connection.JmsTransactionManager;
import org.springframework.jms.core.JmsTemplate;

@Configuration
@EnableJms
@PropertySource({"classpath:persistence-multiple-db-boot.properties"})
public class JmsConfig {

		@Autowired
	    private Environment env;
	
    @Bean(name="jmsTransactionManager")
    @Primary
    public JmsTransactionManager jmsTransactionManager() {
        JmsTransactionManager jmsTransactionManager = new JmsTransactionManager();
        jmsTransactionManager.setConnectionFactory(activemqConnectionFactory());
        return jmsTransactionManager;
    }

    @Bean
    @Primary
    public JmsComponent jmsComponent() {
    
        JmsComponent jmsComponent = JmsComponent.jmsComponentTransacted(activemqConnectionFactory(), jmsTransactionManager());
        jmsComponent.setTestConnectionOnStartup(true);
        jmsComponent.setTransacted(true);
        jmsComponent.setConnectionFactory(activemqConnectionFactory());
        jmsComponent.setTransactionManager(jmsTransactionManager());
        return jmsComponent;
    }
    
    
    @Bean(name="jmstemplate")
    @Primary
    public JmsTemplate jmsTemplate() {
        JmsTemplate jmsTemplate = new JmsTemplate();
        jmsTemplate.setConnectionFactory(activemqConnectionFactory());
        jmsTemplate.setDefaultDestinationName(env.getProperty("input.queue"));
        return jmsTemplate;
    }

    @Bean
    @Primary
	public ConnectionFactory activemqConnectionFactory() {
		RedeliveryPolicy rp = new RedeliveryPolicy();
		rp.setMaximumRedeliveries(RedeliveryPolicy.NO_MAXIMUM_REDELIVERIES);

		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
		connectionFactory.setBrokerURL(env.getProperty("spring.activemq.broker-url"));
		connectionFactory.setUserName(env.getProperty("spring.activemq.user"));
		connectionFactory.setPassword(env.getProperty("spring.activemq.password"));
		connectionFactory.setRedeliveryPolicy(rp);
		return connectionFactory;
	}
    	
  
}
