package com.chain.api.dao.user;

import org.springframework.data.jpa.repository.JpaRepository;

import com.chain.api.model.user.PossessionMultipleDB;

public interface PossessionRepository extends JpaRepository<PossessionMultipleDB, Long> {

}
