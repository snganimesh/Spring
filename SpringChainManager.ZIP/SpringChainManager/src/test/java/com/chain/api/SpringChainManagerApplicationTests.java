package com.chain.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringChainManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
